// src/shared/ListOfOrchids.js
export const OrchidsData = [
  {
    id: '1',
    orchidName: 'Ceasar 4N',
    category: 'Dendrobium',
    isSpecial: true,
    origin: 'Thailand',
    color: 'Purple',
    rating: 4.8,
    image: '/images/orchid-placeholder.svg',
    description: 'Dendrobium nổi bật với màu tím và form hoa cân đối.'
  },
  {
    id: '2',
    orchidName: 'Mini Yaya',
    category: 'Dendrobium',
    isSpecial: true,
    origin: 'Taiwan',
    color: 'Pink',
    rating: 4.6,
    image: '/images/orchid-placeholder.svg',
    description: 'Giống mini nhỏ gọn, phù hợp không gian trưng bày.'
  },
  {
    id: '3',
    orchidName: 'Crystallinum',
    category: 'Dendrobium',
    isSpecial: true,
    origin: 'Southeast Asia',
    color: 'White',
    rating: 4.7,
    image: '/images/orchid-placeholder.svg',
    description: 'Hoa sáng màu, cánh thanh và có tính trang trí cao.'
  },
  {
    id: '4',
    orchidName: 'Damari',
    category: 'Dendrobium',
    isSpecial: false,
    origin: 'Hybrid',
    color: 'Yellow',
    rating: 4.2,
    image: '/images/orchid-placeholder.svg',
    description: 'Giống lai dễ quan sát đặc điểm hình thái.'
  },
  {
    id: '5',
    orchidName: 'Taichung Beauty',
    category: 'Cattleya',
    isSpecial: true,
    origin: 'Taiwan',
    color: 'Violet',
    rating: 4.9,
    image: '/images/orchid-placeholder.svg',
    description: 'Cattleya có hoa lớn, màu sắc nổi bật.'
  },
  {
    id: '6',
    orchidName: 'Snow White',
    category: 'Phalaenopsis',
    isSpecial: false,
    origin: 'Hybrid',
    color: 'White',
    rating: 4.3,
    image: '/images/orchid-placeholder.svg',
    description: 'Phalaenopsis trắng, phù hợp minh họa category khác.'
  },
  {
    id: '7',
    orchidName: 'Golden Shower',
    category: 'Oncidium',
    isSpecial: false,
    origin: 'Hybrid',
    color: 'Yellow',
    rating: 4.4,
    image: '/images/orchid-placeholder.svg',
    description: 'Chùm hoa vàng nhỏ, tạo khác biệt khi lọc category.'
  },
  {
    id: '8',
    orchidName: 'Blue Vanda',
    category: 'Vanda',
    isSpecial: true,
    origin: 'Asia',
    color: 'Blue',
    rating: 4.8,
    image: '/images/orchid-placeholder.svg',
    description: 'Vanda màu xanh tím, dùng để kiểm tra filter và detail.'
  }
];
